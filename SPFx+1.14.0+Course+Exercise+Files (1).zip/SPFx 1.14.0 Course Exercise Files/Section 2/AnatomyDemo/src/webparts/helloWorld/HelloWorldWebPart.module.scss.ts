/* tslint:disable */
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_535804d1',
  container: 'container_535804d1',
  row: 'row_535804d1',
  column: 'column_535804d1',
  'ms-Grid': 'ms-Grid_535804d1',
  title: 'title_535804d1',
  subTitle: 'subTitle_535804d1',
  description: 'description_535804d1',
  button: 'button_535804d1',
  label: 'label_535804d1'
};

export default styles;
/* tslint:enable */