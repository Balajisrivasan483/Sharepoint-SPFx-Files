/* tslint:disable */
require("./GetlistofalllistsWebPart.module.css");
const styles = {
  getlistofalllists: 'getlistofalllists_891d3214',
  teams: 'teams_891d3214',
  welcome: 'welcome_891d3214',
  welcomeImage: 'welcomeImage_891d3214',
  links: 'links_891d3214'
};

export default styles;
/* tslint:enable */