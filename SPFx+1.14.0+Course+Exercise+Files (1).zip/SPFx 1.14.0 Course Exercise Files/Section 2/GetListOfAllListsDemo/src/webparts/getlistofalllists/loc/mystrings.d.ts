declare interface IGetlistofalllistsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
}

declare module 'GetlistofalllistsWebPartStrings' {
  const strings: IGetlistofalllistsWebPartStrings;
  export = strings;
}
