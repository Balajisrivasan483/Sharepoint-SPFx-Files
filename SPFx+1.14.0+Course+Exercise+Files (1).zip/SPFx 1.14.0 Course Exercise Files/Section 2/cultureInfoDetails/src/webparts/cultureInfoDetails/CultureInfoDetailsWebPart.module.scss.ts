/* tslint:disable */
require("./CultureInfoDetailsWebPart.module.css");
const styles = {
  cultureInfoDetails: 'cultureInfoDetails_d128bff5',
  container: 'container_d128bff5',
  row: 'row_d128bff5',
  column: 'column_d128bff5',
  'ms-Grid': 'ms-Grid_d128bff5',
  title: 'title_d128bff5',
  subTitle: 'subTitle_d128bff5',
  description: 'description_d128bff5',
  button: 'button_d128bff5',
  label: 'label_d128bff5'
};

export default styles;
/* tslint:enable */