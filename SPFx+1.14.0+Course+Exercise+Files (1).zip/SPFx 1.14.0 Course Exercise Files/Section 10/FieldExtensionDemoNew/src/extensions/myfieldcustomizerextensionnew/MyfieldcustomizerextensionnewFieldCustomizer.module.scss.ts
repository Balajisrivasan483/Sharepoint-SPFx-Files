/* tslint:disable */
require("./MyfieldcustomizerextensionnewFieldCustomizer.module.css");
const styles = {
  Myfieldcustomizerextensionnew: 'Myfieldcustomizerextensionnew_985fdb4c',
  cell: 'cell_985fdb4c'
};

export default styles;
/* tslint:enable */