/* tslint:disable */
require("./acDemoNew.module.css");
const styles = {
  acdemoapp: 'acdemoapp_046255b2',
  topPlaceholder: 'topPlaceholder_046255b2',
  bottomPlaceholder: 'bottomPlaceholder_046255b2'
};

export default styles;
/* tslint:enable */