/* tslint:disable */
require("./ACDemo.module.css");
const styles = {
  acdemoapp: 'acdemoapp_66bfa94c',
  topPlaceholder: 'topPlaceholder_66bfa94c',
  bottomPlaceholder: 'bottomPlaceholder_66bfa94c'
};

export default styles;
/* tslint:enable */