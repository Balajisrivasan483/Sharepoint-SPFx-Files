
export interface ISoftwareListItem {
    Id: number;
    Title: string;
    SoftwareName: string;
    SoftwareVendor: string;
    SoftwareVersion: string;
    SoftwareDescription: string;       
    
}
