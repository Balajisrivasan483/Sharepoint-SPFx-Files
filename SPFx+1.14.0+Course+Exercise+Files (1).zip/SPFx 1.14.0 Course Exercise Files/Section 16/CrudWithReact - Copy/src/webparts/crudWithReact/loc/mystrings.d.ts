declare interface ICrudWithReactWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CrudWithReactWebPartStrings' {
  const strings: ICrudWithReactWebPartStrings;
  export = strings;
}
