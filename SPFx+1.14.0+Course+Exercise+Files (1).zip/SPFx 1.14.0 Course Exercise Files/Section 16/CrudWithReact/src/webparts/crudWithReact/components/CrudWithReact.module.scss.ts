/* tslint:disable */
require("./CrudWithReact.module.css");
const styles = {
  crudWithReact: 'crudWithReact_8fcbb454',
  container: 'container_8fcbb454',
  row: 'row_8fcbb454',
  column: 'column_8fcbb454',
  'ms-Grid': 'ms-Grid_8fcbb454',
  title: 'title_8fcbb454',
  subTitle: 'subTitle_8fcbb454',
  description: 'description_8fcbb454',
  button: 'button_8fcbb454',
  label: 'label_8fcbb454'
};

export default styles;
/* tslint:enable */