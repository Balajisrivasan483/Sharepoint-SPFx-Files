/* tslint:disable */
require("./ShowAllUsers.module.css");
const styles = {
  showAllUsers: 'showAllUsers_c43f2493',
  container: 'container_c43f2493',
  row: 'row_c43f2493',
  column: 'column_c43f2493',
  'ms-Grid': 'ms-Grid_c43f2493',
  title: 'title_c43f2493',
  subTitle: 'subTitle_c43f2493',
  description: 'description_c43f2493',
  button: 'button_c43f2493',
  label: 'label_c43f2493'
};

export default styles;
/* tslint:enable */