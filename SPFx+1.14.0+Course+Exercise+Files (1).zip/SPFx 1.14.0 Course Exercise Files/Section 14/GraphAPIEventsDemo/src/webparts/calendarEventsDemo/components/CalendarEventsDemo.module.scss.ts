/* tslint:disable */
require("./CalendarEventsDemo.module.css");
const styles = {
  calendarEventsDemo: 'calendarEventsDemo_5b0b1a40',
  container: 'container_5b0b1a40',
  row: 'row_5b0b1a40',
  column: 'column_5b0b1a40',
  'ms-Grid': 'ms-Grid_5b0b1a40',
  title: 'title_5b0b1a40',
  subTitle: 'subTitle_5b0b1a40',
  description: 'description_5b0b1a40',
  button: 'button_5b0b1a40',
  label: 'label_5b0b1a40'
};

export default styles;
/* tslint:enable */