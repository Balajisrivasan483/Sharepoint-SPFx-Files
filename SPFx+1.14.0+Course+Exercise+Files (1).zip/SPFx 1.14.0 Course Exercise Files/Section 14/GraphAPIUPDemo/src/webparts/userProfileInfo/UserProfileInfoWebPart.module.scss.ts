/* tslint:disable */
require("./UserProfileInfoWebPart.module.css");
const styles = {
  userProfileInfo: 'userProfileInfo_7fc95050',
  container: 'container_7fc95050',
  row: 'row_7fc95050',
  column: 'column_7fc95050',
  'ms-Grid': 'ms-Grid_7fc95050',
  title: 'title_7fc95050',
  subTitle: 'subTitle_7fc95050',
  description: 'description_7fc95050',
  button: 'button_7fc95050',
  label: 'label_7fc95050'
};

export default styles;
/* tslint:enable */