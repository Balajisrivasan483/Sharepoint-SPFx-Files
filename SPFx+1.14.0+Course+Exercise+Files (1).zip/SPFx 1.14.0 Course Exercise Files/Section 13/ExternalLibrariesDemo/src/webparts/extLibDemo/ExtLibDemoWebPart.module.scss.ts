/* tslint:disable */
require("./ExtLibDemoWebPart.module.css");
const styles = {
  extLibDemo: 'extLibDemo_5bdc48b6',
  container: 'container_5bdc48b6',
  row: 'row_5bdc48b6',
  column: 'column_5bdc48b6',
  'ms-Grid': 'ms-Grid_5bdc48b6',
  title: 'title_5bdc48b6',
  subTitle: 'subTitle_5bdc48b6',
  description: 'description_5bdc48b6',
  button: 'button_5bdc48b6',
  label: 'label_5bdc48b6'
};

export default styles;
/* tslint:enable */