declare interface IAnonymousApiwpDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AnonymousApiwpDemoWebPartStrings' {
  const strings: IAnonymousApiwpDemoWebPartStrings;
  export = strings;
}
