/* tslint:disable */
require("./ConsumeRestApiwp.module.css");
const styles = {
  consumeRestApiwp: 'consumeRestApiwp_500fe2c0',
  container: 'container_500fe2c0',
  row: 'row_500fe2c0',
  column: 'column_500fe2c0',
  'ms-Grid': 'ms-Grid_500fe2c0',
  title: 'title_500fe2c0',
  subTitle: 'subTitle_500fe2c0',
  description: 'description_500fe2c0',
  button: 'button_500fe2c0',
  label: 'label_500fe2c0'
};

export default styles;
/* tslint:enable */