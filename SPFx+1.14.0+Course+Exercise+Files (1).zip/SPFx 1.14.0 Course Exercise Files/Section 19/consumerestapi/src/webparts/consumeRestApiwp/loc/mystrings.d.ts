declare interface IConsumeRestApiwpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ConsumeRestApiwpWebPartStrings' {
  const strings: IConsumeRestApiwpWebPartStrings;
  export = strings;
}
