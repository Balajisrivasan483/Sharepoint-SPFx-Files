/* tslint:disable */
require("./MyIsolatedWebPartWebPart.module.css");
const styles = {
  myIsolatedWebPart: 'myIsolatedWebPart_f77702d4',
  container: 'container_f77702d4',
  row: 'row_f77702d4',
  column: 'column_f77702d4',
  'ms-Grid': 'ms-Grid_f77702d4',
  title: 'title_f77702d4',
  subTitle: 'subTitle_f77702d4',
  description: 'description_f77702d4',
  button: 'button_f77702d4',
  label: 'label_f77702d4'
};

export default styles;
/* tslint:enable */