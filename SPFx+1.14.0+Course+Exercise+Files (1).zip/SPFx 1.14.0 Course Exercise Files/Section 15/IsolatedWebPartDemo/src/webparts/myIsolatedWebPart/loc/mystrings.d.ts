declare interface IMyIsolatedWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MyIsolatedWebPartWebPartStrings' {
  const strings: IMyIsolatedWebPartWebPartStrings;
  export = strings;
}
