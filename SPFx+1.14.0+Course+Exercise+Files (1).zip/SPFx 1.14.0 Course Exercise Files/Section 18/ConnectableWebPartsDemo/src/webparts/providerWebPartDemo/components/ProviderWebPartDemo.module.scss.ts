/* tslint:disable */
require("./ProviderWebPartDemo.module.css");
const styles = {
  providerWebPartDemo: 'providerWebPartDemo_c98f88b9',
  container: 'container_c98f88b9',
  row: 'row_c98f88b9',
  column: 'column_c98f88b9',
  'ms-Grid': 'ms-Grid_c98f88b9',
  title: 'title_c98f88b9',
  subTitle: 'subTitle_c98f88b9',
  description: 'description_c98f88b9',
  button: 'button_c98f88b9',
  label: 'label_c98f88b9'
};

export default styles;
/* tslint:enable */