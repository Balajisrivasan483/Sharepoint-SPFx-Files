

import { IDepartment } from "./IDepartment";


export type DepartmentSelectedCallback = (department: IDepartment) => void;
