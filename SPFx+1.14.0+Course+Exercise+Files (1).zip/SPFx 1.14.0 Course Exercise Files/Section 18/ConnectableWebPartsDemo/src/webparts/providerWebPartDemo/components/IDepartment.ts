
export interface IDepartment {
    Id: number;
    Title: string;    
}
