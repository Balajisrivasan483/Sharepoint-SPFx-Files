
import { IDepartment } from "./IDepartment";



export interface IProviderWebPartDemoState {
    status: string;
    DepartmentListItems: IDepartment[];
    DepartmentListItem: IDepartment;
  }