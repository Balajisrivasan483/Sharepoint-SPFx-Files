declare interface IConsumerWebPartDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ConsumerWebPartDemoWebPartStrings' {
  const strings: IConsumerWebPartDemoWebPartStrings;
  export = strings;
}
