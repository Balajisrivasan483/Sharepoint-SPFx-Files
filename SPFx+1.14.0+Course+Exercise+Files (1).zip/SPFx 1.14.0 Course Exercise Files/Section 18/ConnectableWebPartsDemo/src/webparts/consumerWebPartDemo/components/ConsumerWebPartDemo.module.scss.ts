/* tslint:disable */
require("./ConsumerWebPartDemo.module.css");
const styles = {
  consumerWebPartDemo: 'consumerWebPartDemo_f785ffd9',
  container: 'container_f785ffd9',
  row: 'row_f785ffd9',
  column: 'column_f785ffd9',
  'ms-Grid': 'ms-Grid_f785ffd9',
  title: 'title_f785ffd9',
  subTitle: 'subTitle_f785ffd9',
  description: 'description_f785ffd9',
  button: 'button_f785ffd9',
  label: 'label_f785ffd9'
};

export default styles;
/* tslint:enable */