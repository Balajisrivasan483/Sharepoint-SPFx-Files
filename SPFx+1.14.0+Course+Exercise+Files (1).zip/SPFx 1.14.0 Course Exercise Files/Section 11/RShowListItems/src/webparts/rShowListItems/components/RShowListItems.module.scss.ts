/* tslint:disable */
require("./RShowListItems.module.css");
const styles = {
  rShowListItems: 'rShowListItems_787c9b08',
  container: 'container_787c9b08',
  row: 'row_787c9b08',
  column: 'column_787c9b08',
  'ms-Grid': 'ms-Grid_787c9b08',
  title: 'title_787c9b08',
  subTitle: 'subTitle_787c9b08',
  description: 'description_787c9b08',
  button: 'button_787c9b08',
  label: 'label_787c9b08'
};

export default styles;
/* tslint:enable */