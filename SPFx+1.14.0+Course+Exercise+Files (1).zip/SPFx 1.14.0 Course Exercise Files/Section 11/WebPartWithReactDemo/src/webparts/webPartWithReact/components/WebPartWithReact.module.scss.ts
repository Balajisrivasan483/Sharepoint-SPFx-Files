/* tslint:disable */
require("./WebPartWithReact.module.css");
const styles = {
  webPartWithReact: 'webPartWithReact_e4c93c95',
  container: 'container_e4c93c95',
  row: 'row_e4c93c95',
  column: 'column_e4c93c95',
  'ms-Grid': 'ms-Grid_e4c93c95',
  title: 'title_e4c93c95',
  subTitle: 'subTitle_e4c93c95',
  description: 'description_e4c93c95',
  button: 'button_e4c93c95',
  label: 'label_e4c93c95'
};

export default styles;
/* tslint:enable */