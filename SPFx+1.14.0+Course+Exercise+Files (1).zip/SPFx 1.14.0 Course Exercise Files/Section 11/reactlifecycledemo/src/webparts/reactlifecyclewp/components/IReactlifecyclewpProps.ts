export interface IReactlifecyclewpProps {
  description: string;
}
