/* tslint:disable */
require("./Reactlifecyclewp.module.css");
const styles = {
  reactlifecyclewp: 'reactlifecyclewp_24e71efc',
  container: 'container_24e71efc',
  row: 'row_24e71efc',
  column: 'column_24e71efc',
  'ms-Grid': 'ms-Grid_24e71efc',
  title: 'title_24e71efc',
  subTitle: 'subTitle_24e71efc',
  description: 'description_24e71efc',
  button: 'button_24e71efc',
  label: 'label_24e71efc'
};

export default styles;
/* tslint:enable */